package com.example.moviepractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviepracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
